﻿using _365EJSC.ERP.Domain.Abstractions.Repositories.Sql.Base;
using _365EJSC.ERP.Domain.Entities.Define;

namespace _365EJSC.ERP.Domain.Abstractions.Repositories.Sql
{
    public interface IWebLocalWardSqlRepository : IGenericSqlRepository<WebLocalWard, int>
    {
    }
}