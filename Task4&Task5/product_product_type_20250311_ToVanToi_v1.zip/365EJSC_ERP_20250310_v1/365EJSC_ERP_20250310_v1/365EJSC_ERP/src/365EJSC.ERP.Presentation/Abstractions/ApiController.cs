﻿using Microsoft.AspNetCore.Mvc;

namespace _365EJSC.ERP.Presentation.Abstractions
{
    /// <summary>
    /// Abstract class for api controller
    /// </summary>
    [ApiController]
    public abstract class ApiController : ControllerBase
    {
    }
}